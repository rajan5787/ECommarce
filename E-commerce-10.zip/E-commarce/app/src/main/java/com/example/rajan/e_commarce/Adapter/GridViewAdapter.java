package com.example.rajan.e_commarce.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.example.rajan.e_commarce.Model.Product_Detail;
import com.example.rajan.e_commarce.R;
import com.example.rajan.e_commarce.Volley.AppController;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Rajan on 2/24/2016.
 */
public class GridViewAdapter extends BaseAdapter {
    private Activity mActivity;
    private ArrayList<Product_Detail> mArrayList;
    LayoutInflater inflater=null;
    ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    public GridViewAdapter(Activity mActivity, ArrayList<Product_Detail> mArrayList){
        this.mActivity=mActivity;
        this.mArrayList=mArrayList;
    }

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout linearLayout = new LinearLayout(mActivity);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        if(inflater==null){
            inflater=(LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(convertView==null) {
            convertView = inflater.inflate(R.layout.datail_item, null);
        }
        if(imageLoader==null){
            imageLoader = AppController.getInstance().getImageLoader();
        }

        TextView name=(TextView)convertView.findViewById(R.id.name);
        ImageView image1=(ImageView)convertView.findViewById(R.id.image1);
        Product_Detail mItem=mArrayList.get(position);
        name.setText(mItem.getName());
     /*  FeedImageView feedImageView=(FeedImageView)convertView.findViewById(R.id.feedImageView);


        if (mItem.getImage() != null) {
            feedImageView.setImageUrl("http://192.168.137.1/photos/"+mItem.getImage(), imageLoader);
            feedImageView.setVisibility(View.VISIBLE);
            feedImageView.setResponseObserver(new FeedImageView.ResponseObserver() {
                @Override
                public void onError() {
                }
                @Override
                public void onSuccess() {
                }
            });
        } else {
            feedImageView.setVisibility(View.GONE);
        }*/
        Picasso.with(mActivity).load("http://192.168.137.1/photos/"+mItem.getImage()).resize(550,550).into(image1);

        return convertView;
    }
}
