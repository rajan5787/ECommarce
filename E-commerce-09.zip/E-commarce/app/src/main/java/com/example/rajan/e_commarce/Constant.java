package com.example.rajan.e_commarce;

import com.example.rajan.e_commarce.database.AppDB;

public class Constant {

	/*
	 * Global database object
	 */
	public static AppDB db;
}
