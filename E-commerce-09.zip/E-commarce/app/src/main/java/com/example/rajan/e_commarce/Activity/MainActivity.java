package com.example.rajan.e_commarce.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;
import com.example.rajan.e_commarce.Adapter.ItemDetailAdapter;
import com.example.rajan.e_commarce.Adapter.RecipeAdapter;
import com.example.rajan.e_commarce.BaseActivity;
import com.example.rajan.e_commarce.R;
import com.example.rajan.e_commarce.vertical.Recipe;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends BaseActivity implements RecyclerView.OnClickListener{
    private LayoutInflater mInflator;
    TextView textView;
    ArrayList mArrayList1;
    private Toolbar toolbar;
    DrawerLayout Drawer;
    RecyclerView mRecyclerView;
    RecipeAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    ActionBarDrawerToggle mDrawerToggle;
    CardView cardView;
    RecyclerView mRecyclerView_nishit;
    ItemDetailAdapter mAdapter_nishit;
    LinearLayoutManager mLayoutManager_nishit;
    RecyclerView mRecyclerView_newly;
    ItemDetailAdapter mAdapter_newly;
    LinearLayoutManager mLayoutManager_newly;
    RecyclerView mRecyclerView_rajan;
    ItemDetailAdapter mAdapter_rajan;
    LinearLayoutManager mLayoutManager_rajan;
    RecyclerView mRecyclerView_akar;
    ItemDetailAdapter mAdapter_akar;
    LinearLayoutManager mLayoutManager_akar;
    RecyclerView mRecyclerView_jasmin;
    ItemDetailAdapter mAdapter_jasmin;
    LinearLayoutManager mLayoutManager_jasmin;


    public MainActivity setCardView(CardView cardView) {
        this.cardView = cardView;

        return this;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
            try {
                Method m = menu.getClass().getDeclaredMethod(
                        "setOptionalIconsVisible", Boolean.TYPE);
                m.setAccessible(true);
                m.invoke(menu, true);
            } catch (NoSuchMethodException e) {
                Log.e("Overflow Menu", "onMenuOpened", e);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        ArrayList catagory = new ArrayList<String>();
        catagory.add("beef");
        catagory.add("cheese");
        catagory.add("salsa");
        catagory.add("tortilla");
        catagory.add("ketchup");
        catagory.add("bun");

        Recipe taco = new Recipe("taco", Arrays.asList("beef", "cheese", "salsa", "tortilla"));
        Recipe quesadilla = new Recipe("quesadilla", Arrays.asList("cheese", "tortilla"));
        Recipe burger = new Recipe("burger", Arrays.asList("beef", "cheese", "ketchup", "bun"));
        final List<Recipe> recipes = Arrays.asList(taco, quesadilla, burger);


        mArrayList1 = new ArrayList<String>();
        mArrayList1.add("Rajan1");
        mArrayList1.add("Akar2");
        mArrayList1.add("Nishit3");
        mArrayList1.add("Vivik4");
        mArrayList1.add("Jasmin5");

        maping();


        mAdapter = new RecipeAdapter(this, recipes);
        mAdapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {
                Recipe expandedRecipe = recipes.get(position);
                String toastMsg = getResources().getString(R.string.expanded, expandedRecipe.getName());
                Toast.makeText(MainActivity.this, toastMsg, Toast.LENGTH_SHORT)
                        .show();

            }

            @Override
            public void onListItemCollapsed(int position) {
                Recipe collapsedRecipe = recipes.get(position);

                String toastMsg = getResources().getString(R.string.collapsed, collapsedRecipe.getName());
                Toast.makeText(MainActivity.this, toastMsg, Toast.LENGTH_SHORT)
                        .show();
            }
        });

        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        /*newly*/
        mRecyclerView_newly.setHasFixedSize(true);
        mAdapter_newly = new ItemDetailAdapter(mArrayList1);
        mRecyclerView_newly.setAdapter(mAdapter_newly);
        mLayoutManager_newly = new LinearLayoutManager(this);
        mLayoutManager_newly.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView_newly.setLayoutManager(mLayoutManager_newly);



        /*Rajan*/
        mRecyclerView_rajan.setHasFixedSize(true);
        mAdapter_rajan = new ItemDetailAdapter(mArrayList1);
        mRecyclerView_rajan.setAdapter(mAdapter_rajan);
        mLayoutManager_rajan = new LinearLayoutManager(this);
        mLayoutManager_rajan.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView_rajan.setLayoutManager(mLayoutManager_rajan);

        /*Nishit*/

        mRecyclerView_nishit.setHasFixedSize(true);
        mAdapter_nishit = new ItemDetailAdapter(mArrayList1);
        mRecyclerView_nishit.setAdapter(mAdapter_nishit);
        mLayoutManager_nishit = new LinearLayoutManager(this);
        mLayoutManager_nishit.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView_nishit.setLayoutManager(mLayoutManager_nishit);

         /*Akar*/

        mRecyclerView_akar.setHasFixedSize(true);
        mAdapter_akar = new ItemDetailAdapter(mArrayList1);
        mRecyclerView_akar.setAdapter(mAdapter_akar);
        mLayoutManager_akar = new LinearLayoutManager(this);
        mLayoutManager_akar.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView_akar.setLayoutManager(mLayoutManager_akar);

        /*Jasmin*/

        mRecyclerView_jasmin.setHasFixedSize(true);
        mAdapter_jasmin = new ItemDetailAdapter(mArrayList1);
        mRecyclerView_jasmin.setAdapter(mAdapter_jasmin);
        mLayoutManager_jasmin = new LinearLayoutManager(this);
        mLayoutManager_jasmin.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView_jasmin.setLayoutManager(mLayoutManager_jasmin);

        /*drower*/
        mDrawerToggle = new ActionBarDrawerToggle(this,Drawer,toolbar,R.string.openDrawer,R.string.closeDrawer){

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

        };
         // Drawer Toggle Object Made
        Drawer.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        Intent i;
        //noinspection SimplifiableIfStatement
        switch (id){

            case R.id.action_orders:
                i = new Intent(this,Cart.class);
                startActivity(i);
                break;

            case R.id.action_Account:
                i = new Intent(MainActivity.this,MyAccount.class);
                startActivity(i);

                break;
            case R.id.action_login:
                i = new Intent(MainActivity.this,Login.class);
                startActivity(i);

                break;
            case R.id.action_SignOut:
                i = new Intent(MainActivity.this,Signup.class);
                startActivity(i);

                break;
        }


        return super.onOptionsItemSelected(item);
    }

    public void maping(){
        cardView = (CardView)findViewById(R.id.cardview_project_detail);

        mRecyclerView = (RecyclerView) findViewById(R.id.RecyclerView);
        mRecyclerView_nishit = (RecyclerView) findViewById(R.id.RecyclerView_nishit);
        mRecyclerView_newly = (RecyclerView) findViewById(R.id.RecyclerView_newly);
        mRecyclerView_rajan = (RecyclerView) findViewById(R.id.RecyclerView_rajan);
        mRecyclerView_akar = (RecyclerView) findViewById(R.id.RecyclerView_akar);
        mRecyclerView_jasmin = (RecyclerView) findViewById(R.id.RecyclerView_jasmin);

        Drawer = (DrawerLayout) findViewById(R.id.DrawerLayout);

    }




    @Override
    public void onClick(View v) {
        Toast.makeText(this,"rrrrr",Toast.LENGTH_SHORT).show();
    }



}