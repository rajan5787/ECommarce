package com.example.rajan.e_commarce.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;

import com.example.rajan.e_commarce.Adapter.MyListViewAdapter;
import com.example.rajan.e_commarce.R;

import org.json.JSONObject;

import java.util.ArrayList;

import static com.example.rajan.e_commarce.Constant.db;

public class Cart extends AppCompatActivity {


    ListView listView;
    ArrayList<JSONObject> listStudents;
    Button button;
    MyListViewAdapter myListViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);


        listView = (ListView)findViewById(R.id.list_view);

      //  button = (Button)findViewById(R.id.button);
        listStudents = db.getStudents();

        Log.d("Students", "Students" + db.getStudents());


        if(listStudents!=null && listStudents.size()>0){

            myListViewAdapter = new MyListViewAdapter(Cart.this,listStudents);
            listView.setAdapter(myListViewAdapter);
        }


    }
}
