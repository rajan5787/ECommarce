package com.example.rajan.e_commarce.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.rajan.e_commarce.Activity.Remove;
import com.example.rajan.e_commarce.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.example.rajan.e_commarce.Constant.db;

public class MyListViewAdapter extends ArrayAdapter<JSONObject>
{
	Activity activity;
	Context context;


	public MyListViewAdapter(Activity activity, ArrayList<JSONObject> listStudents) {

		super(activity, R.layout.cart, listStudents);
		this.activity = activity;
		this.listStudents = listStudents;
	}

	ArrayList<JSONObject> listStudents;

	private class ViewHolder {
        TextView txtViewRollNo;
        TextView txtViewName;
		Button remove;
	}

	public View getView(final int position, View convertView, ViewGroup parent)
	{
		// TODO Auto-generated method stub
		final ViewHolder holder;
		LayoutInflater inflater =  activity.getLayoutInflater();

		if (convertView == null)
		{

			convertView = inflater.inflate(R.layout.cart, null);
			holder = new ViewHolder();
			holder.txtViewRollNo = (TextView) convertView.findViewById(R.id.txtViewName);
			holder.txtViewName = (TextView) convertView.findViewById(R.id.txtViewRollNo);
			holder.remove = (Button)convertView.findViewById(R.id.remove);
			context = convertView.getContext();
			convertView.setTag(holder);

		}
		else
		{
			holder = (ViewHolder) convertView.getTag();
		}

		final JSONObject objStudent = listStudents.get(position);


		holder.remove.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				String id = "2";
				try {
					id = objStudent.getString("Ïd").toString();
				} catch (JSONException e) {
					e.printStackTrace();
				}

				db.removeStudent(Integer.parseInt(id));

				listStudents = db.getStudents();

				Log.d("Students", "Students" + db.getStudents());

				Intent i = new Intent(context,Remove.class);
				context.startActivity(i);
				((Activity)context).finish();


			}
		});


		try {
			holder.txtViewRollNo.setText(objStudent.getString("Name"));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			holder.txtViewName.setText(objStudent.getString("Id"));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	return convertView;
	}
}