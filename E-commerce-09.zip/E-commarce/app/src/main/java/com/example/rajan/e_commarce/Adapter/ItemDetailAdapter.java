package com.example.rajan.e_commarce.Adapter;


import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.rajan.e_commarce.Activity.Cart;
import com.example.rajan.e_commarce.Activity.Product_full_Detail;
import com.example.rajan.e_commarce.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.example.rajan.e_commarce.Constant.db;

/**
 * Created by rajan on 1/4/16.
 */


public class ItemDetailAdapter extends RecyclerView.Adapter<ItemDetailAdapter.ViewHolder> {
    public ArrayList mArrayList;
    Context context;
    String categary;
    Button add,show;
    public ItemDetailAdapter(ArrayList arrayList) {
        this.mArrayList = arrayList;
        //this.categary = cetagary;
    }

    @Override
    public ItemDetailAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_item_detail, parent, false);

        return new ItemDetailAdapter.ViewHolder(view);

    }


    @Override
    public void onBindViewHolder(ItemDetailAdapter.ViewHolder holder, int position) {
        String s = mArrayList.get(position).toString();

      /*  switch (categary){

            case "newly" :
                holder.tvDesNature.setText("Newly");
                break;
            case "nishit" :
                holder.tvDesNature.setText("nishit");
                break;
            case "rajan" :
                holder.tvDesNature.setText("Rajan");
                break;
            case "akar" :
                holder.tvDesNature.setText("akar");
                break;
            case "jasmin" :
                holder.tvDesNature.setText("jasmin");

        }
*/
    }


    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        protected TextView tvDesNature;





        public ViewHolder(final View v) {
            super(v);
//tvDesNature = (TextView) v.findViewById(R.id.description);

            context = itemView.getContext();
            CardView cardView = (CardView) itemView.findViewById(R.id.cardview_project_detail);
            itemView.setClickable(true);
            itemView.setOnClickListener(this);
            tvDesNature = (TextView) itemView.findViewById(R.id.description);

            add = (Button) v.findViewById(R.id.add);
            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    JSONObject objStudent = new JSONObject();
                    try {
                        objStudent.put("Id", "2");

                        objStudent.put("Name", "Nishit");
                        objStudent.put("Price", "100");

                        // Log.d("Cart Item", "Item" + objStudent);
                        db.insertStudent(objStudent);

                        Log.d("Cart", "Cart Item" + objStudent);
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }


                    Intent i = new Intent(context,Cart.class);
                    context.startActivity(i);
                   // ((Activity)context).finish();



                }
            });


        }


        @Override
        public void onClick(View v) {
            Intent i = new Intent(context,Product_full_Detail.class);
            i.putExtra("Name", tvDesNature.getText().toString());
            context.startActivity(i);

        }
    }



}